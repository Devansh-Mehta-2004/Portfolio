async function handler({ message }) {
  if (!message) {
    return {
      error: "Message is required",
    };
  }

  const systemContext = `You are a chat assistant for Devansh Mehta, a Full Stack Developer and Mechatronics Engineering student at Jabalpur Engineering College.

Background:
- Currently pursuing BTech in Mechatronics (2023-2027)
- Specializes in full-stack web development
- Skilled in front-end and back-end technologies

Technical Skills:
- Front-End Development (85%)
- Back-End Development (75%)
- UI/UX Design (80%)
- Python (85%)
- C/C++ (80%)
- Project Management (75%)

Projects:
1. E-Commerce Platform: Full-stack solution using React and Node.js
2. Task Management App: Collaborative project management tool
3. Social Media Dashboard: Analytics dashboard for social media metrics

Contact:
- Email: devanshmehta4444@gmail.com
- Phone: +91 8989666407
- LinkedIn: devansh-mehta-b2b2b7257
- GitHub: devansh-mehta-04

Please provide helpful, friendly responses about Devansh's background, projects, or skills. If asked about availability or collaboration, direct them to the contact information.`;

  try {
    const response = await fetch("/integrations/chat-gpt/conversationgpt4", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messages: [
          {
            role: "system",
            content: systemContext,
          },
          {
            role: "user",
            content: message,
          },
        ],
      }),
    });

    const data = await response.json();

    if (!data.status) {
      return {
        error: "Failed to generate response",
      };
    }

    return {
      response: data.result,
    };
  } catch (error) {
    return {
      error: "Failed to process message",
    };
  }
}