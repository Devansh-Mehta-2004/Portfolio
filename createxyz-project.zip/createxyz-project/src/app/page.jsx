"use client";
import React from "react";
import AiChat from "../components/ai-chat";

function MainComponent() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeFilter, setActiveFilter] = useState("all");
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });
  const [formStatus, setFormStatus] = useState({ type: "", message: "" });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const skills = {
    frontend: [
      { name: "HTML", level: 85 },
      { name: "CSS", level: 80 },
      { name: "Javascript", level: 90 },
    ],
    backend: [
      { name: "Node.js", level: 75 },
      { name: "SQl", level: 85 },
      { name: "MongoDB", level: 80 },
      { name: "Python", level: 85 },
    ],
    otherLanguages: [
      { name: "C language", level: 85 },
      { name: "C++", level: 80 },
    ],
    additional: [
      { name: "Video Editing", level: 75 },
      { name: "Leadership", level: 85 },
    ],
  };
  const projects = [
    {
      title: "E-Commerce Platform",
      description: "Full-stack e-commerce solution with React and Node.js",
      image: "/project1.jpg",
      technologies: ["react", "node"],
      github: "https://github.com/Devansh-Mehta-2004",
      live: "https://www.create.xyz/app/c7f88f44-14db-4c46-849c-e19065b4fa2e",
    },
    {
      title: "Task Management App",
      description: "Collaborative task management application",
      image: "/project2.jpg",
      technologies: ["react", "python"],
      github: "https://github.com/Devansh-Mehta-2004",
      live: "https://www.create.xyz/app/c7f88f44-14db-4c46-849c-e19065b4fa2e",
    },
    {
      title: "Social Media Dashboard",
      description: "Analytics dashboard for social media metrics",
      image: "/project3.jpg",
      technologies: ["react", "node"],
      github: "https://github.com/Devansh-Mehta-2004",
      live: "https://www.create.xyz/app/c7f88f44-14db-4c46-849c-e19065b4fa2e",
    },
  ];
  const education = [
    {
      institution: "Jabalpur Engineering College",
      degree: "Bachelor of Technology - BTech, Mechatronics",
      year: "Sep 2023 - Sep 2027",
      icon: "fa-university",
      additionalInfo:
        "Currently pursuing with focus on robotics and automation systems",
    },
    {
      institution:
        "Pandit Lajja Shankar Jha Model Higher Secondary School of Excellence",
      degree: "Higher Secondary Education",
      year: "Mar 2020 - Mar 2023",
      icon: "fa-graduation-cap",
      additionalInfo:
        "Graduated with distinction in Physics, Chemistry, and Mathematics",
    },
    {
      institution: "Aditya Convert School Senior Secondary School",
      degree: "Secondary Education",
      year: "Mar 2017 - Mar 2020",
      icon: "fa-school",
      additionalInfo:
        "Active participation in science exhibitions and academic competitions",
    },
    {
      institution: "Somja Nursery And Primary School",
      degree: "Primary Education",
      year: "2007 - 2017",
      icon: "fa-child",
      additionalInfo: null,
    },
  ];
  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      setFormStatus({ type: "success", message: "Message sent successfully!" });
      setFormData({ name: "", email: "", message: "" });
    } catch (error) {
      setFormStatus({ type: "error", message: "Failed to send message." });
    }
    setIsSubmitting(false);
  };
  const getNavLink = (item) => {
    switch (item) {
      case "About":
        return "https://www.create.xyz/app/57e7a7aa-3e46-4391-8035-59f7f7422bf4";
      case "Education":
        return "https://www.create.xyz/app/1b51b5e1-1295-4f1a-b86c-62b0968b012d";
      case "Skills":
        return "https://www.create.xyz/app/73551bb1-322f-4568-a847-6e27b4b95b04";
      case "Projects":
        return "https://www.create.xyz/app/c7f88f44-14db-4c46-849c-e19065b4fa2e";
      case "Contact":
        return "https://www.create.xyz/app/da55e7f9-b3a5-48d0-84bb-3b4688233a0f";
      case "Certifications":
        return "https://www.create.xyz/app/c02b4fd5-77b4-4154-94bc-feec77a89db1";
      default:
        return `/${item.toLowerCase()}`;
    }
  };

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 font-inter">
      <nav className="fixed w-full bg-white dark:bg-gray-900 z-50 border-b border-gray-200 dark:border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <span className="text-xl font-bold text-gray-900 dark:text-white">
              Portfolio
            </span>
            <div className="hidden md:flex space-x-8">
              <a
                href="https://www.create.xyz/app/bda19650-59e0-4d5c-9d80-da429604c092"
                className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors duration-200 relative group"
              >
                Home
                <span className="absolute bottom-0 left-0 w-full h-0.5 bg-gray-900 dark:bg-white transform scale-x-0 group-hover:scale-x-100 transition-transform duration-200"></span>
              </a>
              {["About", "Education", "Skills", "Projects", "Contact"].map(
                (item) => (
                  <a
                    key={item}
                    href={getNavLink(item)}
                    className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors duration-200 relative group"
                  >
                    {item}
                    <span className="absolute bottom-0 left-0 w-full h-0.5 bg-gray-900 dark:bg-white transform scale-x-0 group-hover:scale-x-100 transition-transform duration-200"></span>
                  </a>
                )
              )}
              <a
                href={getNavLink("Certifications")}
                className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors duration-200 relative group"
              >
                Certifications
                <span className="absolute bottom-0 left-0 w-full h-0.5 bg-gray-900 dark:bg-white transform scale-x-0 group-hover:scale-x-100 transition-transform duration-200"></span>
              </a>
            </div>
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors duration-200"
            >
              <i
                className={`fas ${
                  isMenuOpen ? "fa-times" : "fa-bars"
                } text-2xl`}
              ></i>
            </button>
          </div>
        </div>

        <div
          className={`md:hidden ${
            isMenuOpen ? "block" : "hidden"
          } absolute w-full bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800`}
        >
          <a
            href="https://www.create.xyz/app/bda19650-59e0-4d5c-9d80-da429604c092"
            className="block px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors duration-200"
          >
            Home
          </a>
          {["About", "Education", "Skills", "Projects", "Contact"].map(
            (item) => (
              <a
                key={item}
                href={getNavLink(item)}
                className="block px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors duration-200"
              >
                {item}
              </a>
            )
          )}
          <a
            href={getNavLink("Certifications")}
            className="block px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors duration-200"
          >
            Certifications
          </a>
        </div>
      </nav>
      <section
        id="home"
        className="min-h-screen flex items-center justify-center relative pt-24"
      >
        <div className="text-center">
          <div className="profile-image mx-auto mb-8">
            <img
              src="https://ucarecdn.com/244b1040-d61c-4ece-9a83-c805baa6820b/-/format/auto/"
              alt="Professional portrait of a full-stack developer"
              className="w-full h-full object-cover object-center"
              loading="eager"
            />
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4 name-animation">
            Devansh Mehta
          </h2>
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 dark:text-white mb-4">
            Full-Stack Web Developer
          </h1>
          <p className="text-xl text-gray-700 dark:text-gray-300 mb-8">
            Building modern web experiences with cutting-edge technologies
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <a
              href="https://www.create.xyz/app/c7f88f44-14db-4c46-849c-e19065b4fa2e"
              className="bg-gray-900 text-white px-10 py-4 rounded-lg hover:bg-gray-800 transform hover:scale-105 transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              View Projects
            </a>
            <a
              href="https://www.create.xyz/app/da55e7f9-b3a5-48d0-84bb-3b4688233a0f"
              className="border-2 border-gray-900 text-gray-900 dark:text-white px-10 py-4 rounded-lg hover:bg-gray-900 hover:text-white transform hover:scale-105 transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              Contact Me
            </a>
          </div>
        </div>
      </section>

      <section id="about" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">
                About Me
              </h2>
              <p className="text-gray-700 dark:text-gray-300">
                I am a student at Jabalpur Engineering College, pursuing
                Mechatronics engineering. Alongside my studies, I have developed
                skills as a full-stack web developer. I enjoy learning new
                things and expanding my knowledge in both my field of study and
                technology. I'm always eager to take on new challenges and grow
                further.
              </p>
            </div>
            <div>
              {Object.entries(skills).map(([category, items]) => (
                <div key={category} className="mb-6">
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4 capitalize">
                    {category}
                  </h3>
                  {items.map((skill) => (
                    <div key={skill.name} className="mb-4">
                      <div className="flex justify-between mb-1">
                        <span className="text-gray-700 dark:text-gray-300">
                          {skill.name}
                        </span>
                        <span className="text-gray-700 dark:text-gray-300">
                          {skill.level}%
                        </span>
                      </div>
                      <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded">
                        <div
                          className="h-2 bg-gray-900 dark:bg-gray-300 rounded"
                          style={{ width: `${skill.level}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
      <section
        id="education"
        className="py-20 px-4 bg-gray-50 dark:bg-gray-800"
      >
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-12 text-center">
            Education
          </h2>
          <div className="space-y-8">
            {education.map((edu, index) => (
              <div key={index} className="flex items-start">
                <div className="flex items-center justify-center w-12 h-12 rounded-full bg-gray-900 dark:bg-gray-700">
                  <i className={`fas ${edu.icon} text-white`}></i>
                </div>
                <div className="ml-4">
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                    {edu.institution}
                  </h3>
                  <p className="text-gray-700 dark:text-gray-300">
                    {edu.degree}
                  </p>
                  <p className="text-gray-600 dark:text-gray-400">{edu.year}</p>
                  {edu.additionalInfo && (
                    <p className="text-gray-600 dark:text-gray-400 mt-1 text-sm italic">
                      {edu.additionalInfo}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="projects" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-12 text-center">
            Projects
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <div
                key={index}
                className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden"
              >
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                    {project.title}
                  </h3>
                  <p className="text-gray-700 dark:text-gray-300 mb-4">
                    {project.description}
                  </p>
                  <div className="flex space-x-4">
                    <a
                      href={project.github}
                      className="text-gray-900 dark:text-white hover:text-gray-700"
                    >
                      <i className="fab fa-github text-xl"></i>
                    </a>
                    <a
                      href={project.live}
                      className="text-gray-900 dark:text-white hover:text-gray-700"
                    >
                      <i className="fas fa-external-link-alt text-xl"></i>
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="contact" className="py-20 px-4 bg-gray-50 dark:bg-gray-800">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-12 text-center">
            Contact Me
          </h2>
          <div className="mb-8 text-center">
            <p className="text-gray-700 dark:text-gray-300 mb-2">
              <i className="fas fa-phone mr-2"></i>
              <a
                href="https://www.create.xyz/app/da55e7f9-b3a5-48d0-84bb-3b4688233a0f"
                className="hover:text-gray-900 dark:hover:text-white"
              >
                +91 8989666407
              </a>
            </p>
            <p className="text-gray-700 dark:text-gray-300">
              <i className="fas fa-envelope mr-2"></i>
              <a
                href="https://www.create.xyz/app/da55e7f9-b3a5-48d0-84bb-3b4688233a0f"
                className="hover:text-gray-900 dark:hover:text-white"
              >
                devanshmehta4444@gmail.com
              </a>
            </p>
          </div>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <input
                type="text"
                name="name"
                placeholder="Your Name"
                value={formData.name}
                onChange={(e) =>
                  setFormData({ ...formData, name: e.target.value })
                }
                className="w-full px-4 py-3 rounded border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white"
                required
              />
            </div>
            <div>
              <input
                type="email"
                name="email"
                placeholder="Your Email"
                value={formData.email}
                onChange={(e) =>
                  setFormData({ ...formData, email: e.target.value })
                }
                className="w-full px-4 py-3 rounded border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white"
                required
              />
            </div>
            <div>
              <textarea
                name="message"
                placeholder="Your Message"
                value={formData.message}
                onChange={(e) =>
                  setFormData({ ...formData, message: e.target.value })
                }
                className="w-full px-4 py-3 rounded border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white h-32"
                required
              ></textarea>
            </div>
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-gray-900 text-white px-8 py-3 rounded hover:bg-gray-800"
            >
              {isSubmitting ? "Sending..." : "Send Message"}
            </button>
            {formStatus.message && (
              <div
                className={`text-center ${
                  formStatus.type === "success"
                    ? "text-green-600"
                    : "text-red-600"
                }`}
              >
                {formStatus.message}
              </div>
            )}
          </form>
          <div className="mt-12 flex justify-center space-x-6">
            <a
              href="https://www.linkedin.com/in/devansh-mehta-9360b8357?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-900 dark:text-white hover:text-gray-700"
            >
              <i className="fab fa-linkedin text-2xl"></i>
            </a>
            <a
              href="https://github.com/Devansh-Mehta-2004"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-900 dark:text-white hover:text-gray-700"
            >
              <i className="fab fa-github text-2xl"></i>
            </a>
            <a
              href="https://twitter.com/devansh_mehta04"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-900 dark:text-white hover:text-gray-700"
            >
              <i className="fab fa-twitter text-2xl"></i>
            </a>
          </div>
        </div>
      </section>

      <style jsx global>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideIn {
          from { transform: translateX(-100%); }
          to { transform: translateX(0); }
        }

        @keyframes nameAnimation {
          0% { opacity: 0; transform: translateY(20px); }
          100% { opacity: 1; transform: translateY(0); }
        }

        @keyframes glowingRing {
          0% { box-shadow: 0 0 15px rgba(229, 231, 235, 0.3); }
          50% { box-shadow: 0 0 30px rgba(229, 231, 235, 0.7); }
          100% { box-shadow: 0 0 15px rgba(229, 231, 235, 0.3); }
        }

        .animate-fadeIn {
          animation: fadeIn 0.6s ease-out forwards;
        }

        .animate-slideIn {
          animation: slideIn 0.3s ease-out forwards;
        }

        .name-animation {
          opacity: 0;
          animation: nameAnimation 1s ease-out forwards;
          animation-delay: 0.3s;
        }

        .profile-image {
          width: 256px;
          height: 256px;
          border-radius: 50%;
          overflow: hidden;
          margin: 0 auto;
          position: relative;
          border: 4px solid #e5e7eb;
          background-color: #f3f4f6;
          animation: glowingRing 3s infinite;
        }

        .profile-image img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          object-position: center top;
        }

        @media (max-width: 768px) {
          .profile-image {
            width: 192px;
            height: 192px;
          }
        }
      `}</style>
      <AiChat initialMessage="Hi! I'm Devansh's AI assistant. I can tell you more about his skills, projects, or experience. What would you like to know?" />
    </div>
  );
}

export default MainComponent;