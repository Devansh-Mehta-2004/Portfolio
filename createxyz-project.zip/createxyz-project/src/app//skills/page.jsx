"use client";
import React from "react";
import HomeButton from "../../components/home-button";

function MainComponent() {
  const [isMenuOpen, setIsMenuOpen] = useState("frontend");
  const [activeCategory, setActiveCategory] = useState("frontend");
  const skills = {
    frontend: [
      { name: "Front-End Development", level: 85, icon: "fa-code" },
      { name: "User Experience (UX)", level: 80, icon: "fa-user" },
      { name: "Canva", level: 90, icon: "fa-paint-brush" },
      { name: "React", level: 85, icon: "fa-react" },
      { name: "HTML/CSS", level: 90, icon: "fa-html5" },
      { name: "JavaScript", level: 85, icon: "fa-js" },
    ],
    backend: [
      { name: "Back-End Development", level: 75, icon: "fa-server" },
      { name: "C Programming", level: 85, icon: "fa-code" },
      { name: "C++", level: 80, icon: "fa-file-code" },
      { name: "Python", level: 85, icon: "fa-python" },
      { name: "Node.js", level: 75, icon: "fa-node" },
      { name: "Database Management", level: 80, icon: "fa-database" },
    ],
    additional: [
      { name: "Video Editing", level: 75, icon: "fa-video" },
      { name: "Leadership", level: 85, icon: "fa-users" },
      { name: "Problem Solving", level: 90, icon: "fa-puzzle-piece" },
      { name: "Team Collaboration", level: 85, icon: "fa-handshake" },
      { name: "Project Management", level: 80, icon: "fa-tasks" },
    ],
  };

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <HomeButton onClick={() => (window.location.href = "/")} />
      <nav className="fixed w-full bg-white dark:bg-gray-900 z-50 border-b border-gray-200 dark:border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <span className="text-xl font-bold text-gray-900 dark:text-white">
              Portfolio
            </span>
            <div className="hidden md:flex space-x-8">
              {[
                "Home",
                "About",
                "Education",
                "Skills",
                "Projects",
                "Certifications",
                "Contact",
              ].map((item) => (
                <a
                  key={item}
                  href={
                    item === "Education"
                      ? "https://www.create.xyz/app/1b51b5e1-1295-4f1a-b86c-62b0968b012d"
                      : item === "Projects"
                      ? "https://www.create.xyz/app/c7f88f44-14db-4c46-849c-e19065b4fa2e"
                      : item === "About"
                      ? "https://www.create.xyz/app/57e7a7aa-3e46-4391-8035-59f7f7422bf4"
                      : item === "Contact"
                      ? "https://www.create.xyz/app/da55e7f9-b3a5-48d0-84bb-3b4688233a0f"
                      : item === "Certifications"
                      ? "https://www.create.xyz/app/c02b4fd5-77b4-4154-94bc-feec77a89db1"
                      : item === "Skills"
                      ? "https://www.create.xyz/app/73551bb1-322f-4568-a847-6e27b4b95b04"
                      : `/${
                          item.toLowerCase() === "home"
                            ? ""
                            : item.toLowerCase()
                        }`
                  }
                  className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white"
                >
                  {item}
                </a>
              ))}
            </div>
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden text-gray-700 dark:text-gray-300"
            >
              <i
                className={`fas ${
                  isMenuOpen ? "fa-times" : "fa-bars"
                } text-2xl`}
              ></i>
            </button>
          </div>
        </div>

        <div
          className={`md:hidden ${
            isMenuOpen ? "block" : "hidden"
          } absolute w-full bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800`}
        >
          {[
            "Home",
            "About",
            "Education",
            "Skills",
            "Projects",
            "Certifications",
            "Contact",
          ].map((item) => (
            <a
              key={item}
              href={
                item === "Education"
                  ? "https://www.create.xyz/app/1b51b5e1-1295-4f1a-b86c-62b0968b012d"
                  : item === "Projects"
                  ? "https://www.create.xyz/app/c7f88f44-14db-4c46-849c-e19065b4fa2e"
                  : item === "About"
                  ? "https://www.create.xyz/app/57e7a7aa-3e46-4391-8035-59f7f7422bf4"
                  : item === "Contact"
                  ? "https://www.create.xyz/app/da55e7f9-b3a5-48d0-84bb-3b4688233a0f"
                  : item === "Certifications"
                  ? "https://www.create.xyz/app/c02b4fd5-77b4-4154-94bc-feec77a89db1"
                  : item === "Skills"
                  ? "https://www.create.xyz/app/73551bb1-322f-4568-a847-6e27b4b95b04"
                  : `/${
                      item.toLowerCase() === "home" ? "" : item.toLowerCase()
                    }`
              }
              className="block px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800"
            >
              {item}
            </a>
          ))}
        </div>
      </nav>

      <div className="pt-16 px-4">
        <div className="max-w-7xl mx-auto py-20">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white text-center mb-12">
            Technical Skills
          </h1>
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {Object.keys(skills).map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-6 py-2 rounded-full text-lg ${
                  activeCategory === category
                    ? "bg-gray-900 text-white"
                    : "bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300"
                }`}
              >
                {category.charAt(0).toUpperCase() + category.slice(1)}
              </button>
            ))}
          </div>
          <div className="grid md:grid-cols-2 gap-8">
            {skills[activeCategory].map((skill, index) => (
              <div
                key={index}
                className="bg-gray-50 dark:bg-gray-800 p-6 rounded-lg transform hover:scale-105 transition-transform duration-300"
              >
                <div className="flex items-center mb-4">
                  <i
                    className={`fas ${skill.icon} text-2xl text-gray-900 dark:text-white mr-3`}
                  ></i>
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                    {skill.name}
                  </h3>
                </div>

                <div className="relative pt-1">
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-gray-700 dark:text-gray-300">
                      Proficiency
                    </div>
                    <div className="text-gray-700 dark:text-gray-300">
                      {skill.level}%
                    </div>
                  </div>
                  <div className="flex h-2 mb-4 overflow-hidden bg-gray-200 dark:bg-gray-700 rounded">
                    <div
                      style={{ width: `${skill.level}%` }}
                      className="flex flex-col justify-center bg-gray-900 dark:bg-gray-300 rounded transition-all duration-500"
                    ></div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-16 text-center">
            <p className="text-gray-700 dark:text-gray-300 text-lg mb-8">
              These skills represent my current technical capabilities and are
              continuously evolving as I learn and grow in my development
              journey.
            </p>
            <a
              href="https://www.create.xyz/app/c7f88f44-14db-4c46-849c-e19065b4fa2e"
              className="inline-block bg-gray-900 text-white px-8 py-3 rounded hover:bg-gray-800 transition-colors duration-300"
            >
              View My Projects
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;