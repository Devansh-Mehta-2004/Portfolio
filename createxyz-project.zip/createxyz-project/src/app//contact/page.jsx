"use client";
import React from "react";
import HomeButton from "../../components/home-button";

function MainComponent() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });
  const [formStatus, setFormStatus] = useState({ type: "", message: "" });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      setFormStatus({ type: "success", message: "Message sent successfully!" });
      setFormData({ name: "", email: "", message: "" });
    } catch (error) {
      setFormStatus({ type: "error", message: "Failed to send message." });
    }
    setIsSubmitting(false);
  };

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 py-20 px-4">
      <HomeButton onClick={() => (window.location.href = "/")} />
      <nav className="fixed top-0 left-0 right-0 bg-white dark:bg-gray-900 shadow-md z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-center h-16">
            <div className="flex space-x-8">
              <a
                href="/"
                className="inline-flex items-center px-1 pt-1 text-gray-900 dark:text-white hover:text-gray-600"
              >
                Home
              </a>
              <a
                href="https://www.create.xyz/app/57e7a7aa-3e46-4391-8035-59f7f7422bf4"
                className="inline-flex items-center px-1 pt-1 text-gray-900 dark:text-white hover:text-gray-600"
              >
                About
              </a>
              <a
                href="https://www.create.xyz/app/c7f88f44-14db-4c46-849c-e19065b4fa2e"
                className="inline-flex items-center px-1 pt-1 text-gray-900 dark:text-white hover:text-gray-600"
              >
                Projects
              </a>
              <a
                href="https://www.create.xyz/app/73551bb1-322f-4568-a847-6e27b4b95b04"
                className="inline-flex items-center px-1 pt-1 text-gray-900 dark:text-white hover:text-gray-600"
              >
                Skills
              </a>
              <a
                href="https://www.create.xyz/app/1b51b5e1-1295-4f1a-b86c-62b0968b012d"
                className="inline-flex items-center px-1 pt-1 text-gray-900 dark:text-white hover:text-gray-600"
              >
                Education
              </a>
              <a
                href="https://www.create.xyz/app/c02b4fd5-77b4-4154-94bc-feec77a89db1"
                className="inline-flex items-center px-1 pt-1 text-gray-900 dark:text-white hover:text-gray-600"
              >
                Certifications
              </a>
              <a
                href="https://www.create.xyz/app/da55e7f9-b3a5-48d0-84bb-3b4688233a0f"
                className="inline-flex items-center px-1 pt-1 border-b-2 border-gray-900 dark:border-white text-gray-900 dark:text-white"
              >
                Contact
              </a>
            </div>
          </div>
        </div>
      </nav>
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold text-gray-900 dark:text-white text-center mb-12">
          Get in Touch
        </h1>

        <div className="grid md:grid-cols-2 gap-12 mb-12">
          <div className="space-y-8">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
              Contact Information
            </h2>
            <div className="space-y-4">
              <div className="flex items-center space-x-4 text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors">
                <div className="w-12 h-12 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center">
                  <i className="fas fa-phone text-xl"></i>
                </div>
                <a href="tel:+918989666407">+91 8989666407</a>
              </div>

              <div className="flex items-center space-x-4 text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors">
                <div className="w-12 h-12 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center">
                  <i className="fas fa-envelope text-xl"></i>
                </div>
                <a href="mailto:devanshmehta4444@gmail.com">
                  devanshmehta4444@gmail.com
                </a>
              </div>

              <div className="flex items-center space-x-4 text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors">
                <div className="w-12 h-12 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center">
                  <i className="fas fa-map-marker-alt text-xl"></i>
                </div>
                <a
                  href="https://maps.app.goo.gl/PAFxvExkVTjY4Hxh6"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Janki Nagar, Jabalpur, Madhya Pradesh 482002, India
                </a>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                Connect With Me
              </h3>
              <div className="flex space-x-4">
                <a
                  href="https://www.linkedin.com/in/devansh-mehta-b2b2b7257/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-12 h-12 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
                >
                  <i className="fab fa-linkedin text-xl"></i>
                </a>
                <a
                  href="https://github.com/devansh-mehta-04"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-12 h-12 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
                >
                  <i className="fab fa-github text-xl"></i>
                </a>
                <a
                  href="https://twitter.com/devansh_mehta04"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-12 h-12 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
                >
                  <i className="fab fa-twitter text-xl"></i>
                </a>
              </div>
            </div>
          </div>

          <div className="bg-gray-50 dark:bg-gray-800 p-8 rounded-lg">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
              Send a Message
            </h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <input
                  type="text"
                  name="name"
                  placeholder="Your Name"
                  value={formData.name}
                  onChange={(e) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                  className="w-full px-4 py-3 rounded border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-gray-900 dark:focus:ring-gray-300"
                  required
                />
              </div>
              <div>
                <input
                  type="email"
                  name="email"
                  placeholder="Your Email"
                  value={formData.email}
                  onChange={(e) =>
                    setFormData({ ...formData, email: e.target.value })
                  }
                  className="w-full px-4 py-3 rounded border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-gray-900 dark:focus:ring-gray-300"
                  required
                />
              </div>
              <div>
                <textarea
                  name="message"
                  placeholder="Your Message"
                  value={formData.message}
                  onChange={(e) =>
                    setFormData({ ...formData, message: e.target.value })
                  }
                  className="w-full px-4 py-3 rounded border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white h-32 focus:ring-2 focus:ring-gray-900 dark:focus:ring-gray-300"
                  required
                ></textarea>
              </div>
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-gray-900 dark:bg-gray-700 text-white px-8 py-3 rounded hover:bg-gray-800 dark:hover:bg-gray-600 transition-colors"
              >
                {isSubmitting ? "Sending..." : "Send Message"}
              </button>
              {formStatus.message && (
                <div
                  className={`text-center ${
                    formStatus.type === "success"
                      ? "text-green-600"
                      : "text-red-600"
                  }`}
                >
                  {formStatus.message}
                </div>
              )}
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;