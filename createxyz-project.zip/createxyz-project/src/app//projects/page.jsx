"use client";
import React from "react";
import HomeButton from "../../components/home-button";

function MainComponent() {
  const [selectedProject, setSelectedProject] = useState(null);
  const [filter, setFilter] = useState("all");
  const projects = [
    {
      id: 1,
      title: "E-Commerce Platform",
      description:
        "Full-stack e-commerce solution with React and Node.js. Features include user authentication, product management, shopping cart, and payment integration.",
      image: "/project1.jpg",
      category: "web",
      technologies: ["React", "Node.js", "MongoDB", "Express"],
      github: "https://github.com/devansh-mehta-04/ecommerce",
      live: "#",
      preview: "/project1-preview.jpg",
    },
    {
      id: 2,
      title: "Task Management App",
      description:
        "Collaborative task management application with real-time updates. Includes features for task assignment, progress tracking, and team collaboration.",
      image: "/project2.jpg",
      category: "web",
      technologies: ["React", "Python", "Django", "PostgreSQL"],
      github: "https://github.com/devansh-mehta-04/taskmanager",
      live: "#",
      preview: "/project2-preview.jpg",
    },
    {
      id: 3,
      title: "Social Media Dashboard",
      description:
        "Analytics dashboard for social media metrics tracking. Visualizes engagement metrics, follower growth, and content performance.",
      image: "/project3.jpg",
      category: "analytics",
      technologies: ["React", "Node.js", "D3.js", "Firebase"],
      github: "https://github.com/devansh-mehta-04/social-dashboard",
      live: "#",
      preview: "/project3-preview.jpg",
    },
  ];
  const filteredProjects =
    filter === "all"
      ? projects
      : projects.filter((project) => project.category === filter);

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 pt-16 px-4">
      <HomeButton onClick={() => (window.location.href = "/")} />
      <nav className="bg-white dark:bg-gray-800 shadow-lg fixed w-full top-0 z-40">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-end space-x-4 h-16 items-center">
            <div className="ml-auto flex space-x-4">
              <a
                href="https://www.create.xyz/app/57e7a7aa-3e46-4391-8035-59f7f7422bf4"
                className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white px-3 py-2 rounded-md text-sm font-medium"
              >
                About
              </a>
              <a
                href="https://www.create.xyz/app/1b51b5e1-1295-4f1a-b86c-62b0968b012d"
                className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white px-3 py-2 rounded-md text-sm font-medium"
              >
                Education
              </a>
              <a
                href="https://www.create.xyz/app/c02b4fd5-77b4-4154-94bc-feec77a89db1"
                className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white px-3 py-2 rounded-md text-sm font-medium"
              >
                Certifications
              </a>
              <a
                href="https://www.create.xyz/app/c7f88f44-14db-4c46-849c-e19065b4fa2e"
                className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white px-3 py-2 rounded-md text-sm font-medium"
              >
                Projects
              </a>
              <a
                href="https://www.create.xyz/app/73551bb1-322f-4568-a847-6e27b4b95b04"
                className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white px-3 py-2 rounded-md text-sm font-medium"
              >
                Skills
              </a>
              <a
                href="https://www.create.xyz/app/da55e7f9-b3a5-48d0-84bb-3b4688233a0f"
                className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white px-3 py-2 rounded-md text-sm font-medium"
              >
                Contact
              </a>
            </div>
          </div>
        </div>
      </nav>
      <div className="max-w-7xl mx-auto">
        <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-8 text-center">
          My Projects
        </h1>
        <div className="flex justify-center mb-12 space-x-4">
          <button
            onClick={() => setFilter("all")}
            className={`px-6 py-2 rounded-full ${
              filter === "all"
                ? "bg-gray-900 text-white"
                : "bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300"
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFilter("web")}
            className={`px-6 py-2 rounded-full ${
              filter === "web"
                ? "bg-gray-900 text-white"
                : "bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300"
            }`}
          >
            Web Apps
          </button>
          <button
            onClick={() => setFilter("analytics")}
            className={`px-6 py-2 rounded-full ${
              filter === "analytics"
                ? "bg-gray-900 text-white"
                : "bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300"
            }`}
          >
            Analytics
          </button>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden hover:shadow-lg transition-shadow duration-300"
            >
              <div
                className="relative h-48 cursor-pointer"
                onClick={() => setSelectedProject(project)}
              >
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black bg-opacity-0 hover:bg-opacity-30 transition-opacity duration-300 flex items-center justify-center">
                  <span className="text-white opacity-0 hover:opacity-100">
                    Click to preview
                  </span>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                  {project.title}
                </h3>
                <p className="text-gray-700 dark:text-gray-300 mb-4 line-clamp-2">
                  {project.description}
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.technologies.map((tech, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 rounded-full text-sm"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
                <div className="flex space-x-4">
                  <a
                    href={project.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-900 dark:text-white hover:text-gray-700 flex items-center"
                  >
                    <i className="fab fa-github text-xl mr-2"></i>
                    Code
                  </a>
                  <a
                    href={project.live}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-900 dark:text-white hover:text-gray-700 flex items-center"
                  >
                    <i className="fas fa-external-link-alt text-xl mr-2"></i>
                    Live Demo
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>

        {selectedProject && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white dark:bg-gray-900 rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                    {selectedProject.title}
                  </h2>
                  <button
                    onClick={() => setSelectedProject(null)}
                    className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                  >
                    <i className="fas fa-times text-2xl"></i>
                  </button>
                </div>
                <img
                  src={selectedProject.preview}
                  alt={`${selectedProject.title} preview`}
                  className="w-full rounded-lg mb-6"
                />
                <p className="text-gray-700 dark:text-gray-300 mb-6">
                  {selectedProject.description}
                </p>
                <div className="flex flex-wrap gap-3 mb-6">
                  {selectedProject.technologies.map((tech, index) => (
                    <span
                      key={index}
                      className="px-4 py-2 bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 rounded-full"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
                <div className="flex space-x-4">
                  <a
                    href={selectedProject.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-gray-900 text-white px-6 py-2 rounded hover:bg-gray-800 flex items-center"
                  >
                    <i className="fab fa-github mr-2"></i>
                    View Code
                  </a>
                  <a
                    href={selectedProject.live}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white px-6 py-2 rounded hover:bg-gray-900 hover:text-white flex items-center"
                  >
                    <i className="fas fa-external-link-alt mr-2"></i>
                    Live Demo
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default MainComponent;