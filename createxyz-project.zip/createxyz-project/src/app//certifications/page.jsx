"use client";
import React from "react";
import HomeButton from "../../components/home-button";

function MainComponent() {
  const [language, setLanguage] = useState("en");
  const [isLoading, setIsLoading] = useState(false);
  const translations = {
    en: {
      title: "Professional Certifications",
      viewCertificate: "View Certificate",
      issuedBy: "Issued by",
      issueDate: "Issue Date",
      score: "Score",
      duration: "Duration",
      description: "Description",
      certTitle: "Digital Skills: User Experience",
      certDescription:
        "User experience, known as UX, makes a huge difference to whether a digital product or project succeeds. This course described what UX is and the impact it can have on a business. It explored the foundations of UX design and the design process: design, develop and release. Information architecture was explained in addition to the different UX techniques you can use to test and develop your designs, so that they're ready to release to the market.",
      weeks: "weeks",
      hoursPerWeek: "hours per week",
    },
    es: {
      title: "Certificaciones Profesionales",
      viewCertificate: "Ver Certificado",
      issuedBy: "Emitido por",
      issueDate: "Fecha de emisión",
      score: "Puntuación",
      duration: "Duración",
      description: "Descripción",
      certTitle: "Habilidades Digitales: Experiencia de Usuario",
      certDescription:
        "La experiencia de usuario, conocida como UX, marca una gran diferencia en el éxito de un producto o proyecto digital. Este curso describió qué es UX y el impacto que puede tener en un negocio. Exploró los fundamentos del diseño UX y el proceso de diseño: diseñar, desarrollar y lanzar. Se explicó la arquitectura de la información además de las diferentes técnicas UX que puede usar para probar y desarrollar sus diseños, para que estén listos para lanzarse al mercado.",
      weeks: "semanas",
      hoursPerWeek: "horas por semana",
      about: "Sobre mí",
      education: "Educación",
      certifications: "Certificaciones",
      projects: "Proyectos",
      skills: "Habilidades",
      contact: "Contacto",
    },
  };
  const handleLanguageChange = async (newLanguage) => {
    setIsLoading(true);
    setLanguage(newLanguage);
    await new Promise((resolve) => setTimeout(resolve, 500));
    setIsLoading(false);
  };
  const t = translations[language];

  return (
    <div className="min-h-screen bg-gradient-to-br from-white to-gray-100 dark:from-gray-900 dark:to-gray-800">
      <HomeButton onClick={() => (window.location.href = "/")} />
      <nav className="bg-white dark:bg-gray-800 shadow-lg fixed w-full top-0 z-40">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-end space-x-4 h-16 items-center">
            <a
              href="https://www.create.xyz/app/57e7a7aa-3e46-4391-8035-59f7f7422bf4"
              className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white px-3 py-2 rounded-md text-sm font-medium"
            >
              About
            </a>
            <a
              href="https://www.create.xyz/app/1b51b5e1-1295-4f1a-b86c-62b0968b012d"
              className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white px-3 py-2 rounded-md text-sm font-medium"
            >
              Education
            </a>
            <a
              href="https://www.create.xyz/app/c02b4fd5-77b4-4154-94bc-feec77a89db1"
              className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white px-3 py-2 rounded-md text-sm font-medium"
            >
              Certifications
            </a>
            <a
              href="https://www.create.xyz/app/c7f88f44-14db-4c46-849c-e19065b4fa2e"
              className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white px-3 py-2 rounded-md text-sm font-medium"
            >
              Projects
            </a>
            <a
              href="https://www.create.xyz/app/73551bb1-322f-4568-a847-6e27b4b95b04"
              className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white px-3 py-2 rounded-md text-sm font-medium"
            >
              Skills
            </a>
            <a
              href="https://www.create.xyz/app/da55e7f9-b3a5-48d0-84bb-3b4688233a0f"
              className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white px-3 py-2 rounded-md text-sm font-medium"
            >
              Contact
            </a>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 mt-16">
        <div className="flex justify-between items-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white">
            {t.title}
          </h1>

          <div className="flex space-x-2">
            <button
              onClick={() => handleLanguageChange("en")}
              className={`px-4 py-2 rounded-lg ${
                language === "en"
                  ? "bg-gray-900 text-white"
                  : "bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300"
              }`}
            >
              EN
            </button>
            <button
              onClick={() => handleLanguageChange("es")}
              className={`px-4 py-2 rounded-lg ${
                language === "es"
                  ? "bg-gray-900 text-white"
                  : "bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300"
              }`}
            >
              ES
            </button>
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900 dark:border-white"></div>
          </div>
        ) : (
          <div className="grid md:grid-cols-1 gap-8">
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl overflow-hidden transform hover:scale-[1.02] transition-all duration-300">
              <div className="p-8">
                <div className="flex items-center justify-between mb-6">
                  <img
                    src="/accenture-logo.png"
                    alt="Accenture logo"
                    className="h-12 w-auto"
                  />
                  <div className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-100 px-4 py-2 rounded-full">
                    <span className="font-bold">92%</span>
                  </div>
                </div>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                  {t.certTitle}
                </h2>
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {t.issuedBy}
                    </p>
                    <p className="font-semibold text-gray-900 dark:text-white">
                      Accenture
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {t.issueDate}
                    </p>
                    <p className="font-semibold text-gray-900 dark:text-white">
                      March 2025
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {t.duration}
                    </p>
                    <p className="font-semibold text-gray-900 dark:text-white">
                      3 {t.weeks}, 2 {t.hoursPerWeek}
                    </p>
                  </div>
                </div>
                <div className="mb-6">
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                    {t.description}
                  </p>
                  <p className="text-gray-700 dark:text-gray-300">
                    {t.certDescription}
                  </p>
                </div>

                <a
                  href="https://www.futurelearn.com/certificates/k2vwihr"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-block bg-gray-900 dark:bg-gray-700 text-white px-6 py-3 rounded-lg hover:bg-gray-800 dark:hover:bg-gray-600 transition-colors duration-200"
                >
                  {t.viewCertificate}
                  <i className="fas fa-external-link-alt ml-2"></i>
                </a>
              </div>
            </div>
          </div>
        )}
      </div>

      <style jsx global>{`
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .grid > div {
          animation: fadeInUp 0.6s ease-out forwards;
        }
      `}</style>
    </div>
  );
}

export default MainComponent;