"use client";
import React from "react";
import HomeButton from "../../components/home-button";

function MainComponent() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const skills = [
    { name: "Front-End Development", level: 85, category: "Development" },
    { name: "Back-End Development", level: 75, category: "Development" },
    { name: "UI/UX Design", level: 80, category: "Design" },
    { name: "Python", level: 85, category: "Programming" },
    { name: "C/C++", level: 80, category: "Programming" },
    { name: "Project Management", level: 75, category: "Soft Skills" },
  ];
  const experiences = [
    {
      role: "Student Developer",
      company: "College Projects",
      period: "Sep 2023 - Present",
      description:
        "Leading development teams in creating innovative solutions for real-world problems.",
    },
  ];

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 font-inter">
      <HomeButton
        onClick={() =>
          (window.location.href =
            "https://www.create.xyz/app/bda19650-59e0-4d5c-9d80-da429604c092")
        }
      />
      <nav className="fixed w-full bg-white dark:bg-gray-900 z-50 border-b border-gray-200 dark:border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <span className="text-xl font-bold text-gray-900 dark:text-white">
              Portfolio
            </span>
            <div className="hidden md:flex space-x-8">
              {[
                {
                  name: "Home",
                  href: "https://www.create.xyz/app/bda19650-59e0-4d5c-9d80-da429604c092",
                },
                {
                  name: "About",
                  href: "https://www.create.xyz/app/57e7a7aa-3e46-4391-8035-59f7f7422bf4",
                },
                {
                  name: "Education",
                  href: "https://www.create.xyz/app/1b51b5e1-1295-4f1a-b86c-62b0968b012d",
                },
                {
                  name: "Skills",
                  href: "https://www.create.xyz/app/73551bb1-322f-4568-a847-6e27b4b95b04",
                },
                {
                  name: "Projects",
                  href: "https://www.create.xyz/app/c7f88f44-14db-4c46-849c-e19065b4fa2e",
                },
                {
                  name: "Certifications",
                  href: "https://www.create.xyz/app/c02b4fd5-77b4-4154-94bc-feec77a89db1",
                },
                {
                  name: "Contact",
                  href: "https://www.create.xyz/app/da55e7f9-b3a5-48d0-84bb-3b4688233a0f",
                },
              ].map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white"
                >
                  {item.name}
                </a>
              ))}
            </div>
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden text-gray-700 dark:text-gray-300"
            >
              <i
                className={`fas ${
                  isMenuOpen ? "fa-times" : "fa-bars"
                } text-2xl`}
              ></i>
            </button>
          </div>
        </div>

        <div
          className={`md:hidden ${
            isMenuOpen ? "block" : "hidden"
          } absolute w-full bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800`}
        >
          {[
            {
              name: "Home",
              href: "https://www.create.xyz/app/bda19650-59e0-4d5c-9d80-da429604c092",
            },
            {
              name: "About",
              href: "https://www.create.xyz/app/57e7a7aa-3e46-4391-8035-59f7f7422bf4",
            },
            {
              name: "Education",
              href: "https://www.create.xyz/app/1b51b5e1-1295-4f1a-b86c-62b0968b012d",
            },
            {
              name: "Skills",
              href: "https://www.create.xyz/app/73551bb1-322f-4568-a847-6e27b4b95b04",
            },
            {
              name: "Projects",
              href: "https://www.create.xyz/app/c7f88f44-14db-4c46-849c-e19065b4fa2e",
            },
            {
              name: "Certifications",
              href: "https://www.create.xyz/app/c02b4fd5-77b4-4154-94bc-feec77a89db1",
            },
            {
              name: "Contact",
              href: "https://www.create.xyz/app/da55e7f9-b3a5-48d0-84bb-3b4688233a0f",
            },
          ].map((item) => (
            <a
              key={item.name}
              href={item.href}
              className="block px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800"
            >
              {item.name}
            </a>
          ))}
        </div>
      </nav>

      <main className="pt-16">
        <section className="py-20 px-4">
          <div className="max-w-7xl mx-auto">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <img
                  src="https://ucarecdn.com/244b1040-d61c-4ece-9a83-c805baa6820b/-/format/auto/"
                  alt="Professional headshot"
                  className="rounded-lg shadow-xl w-full h-auto"
                />
              </div>
              <div>
                <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-6">
                  About Me
                </h1>
                <p className="text-gray-700 dark:text-gray-300 mb-6">
                  I'm a passionate Full Stack Developer and Mechatronics
                  Engineering student at Jabalpur Engineering College. My
                  journey in technology began with a curiosity about how things
                  work, which led me to pursue both software development and
                  engineering.
                </p>
                <p className="text-gray-700 dark:text-gray-300 mb-6">
                  I specialize in building responsive web applications using
                  modern technologies and frameworks. My engineering background
                  gives me a unique perspective on problem-solving and system
                  design.
                </p>
                <div className="flex space-x-4">
                  <a
                    href="https://www.linkedin.com/in/devansh-mehta-b2b2b7257/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-900 dark:text-white hover:text-gray-700"
                  >
                    <i className="fab fa-linkedin text-2xl"></i>
                  </a>
                  <a
                    href="https://github.com/devansh-mehta-04"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-900 dark:text-white hover:text-gray-700"
                  >
                    <i className="fab fa-github text-2xl"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 px-4 bg-gray-50 dark:bg-gray-800">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-12 text-center">
              Technical Skills
            </h2>
            <div className="grid md:grid-cols-2 gap-8">
              {skills.map((skill, index) => (
                <div key={index} className="mb-6">
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-700 dark:text-gray-300">
                      {skill.name}
                    </span>
                    <span className="text-gray-700 dark:text-gray-300">
                      {skill.level}%
                    </span>
                  </div>
                  <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gray-900 dark:bg-gray-300 rounded-full animate-slideIn"
                      style={{ width: `${skill.level}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20 px-4">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-12 text-center">
              Professional Experience
            </h2>
            <div className="space-y-8">
              {experiences.map((exp, index) => (
                <div
                  key={index}
                  className="border-l-4 border-gray-900 dark:border-gray-300 pl-6 animate-fadeIn"
                >
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                    {exp.role}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    {exp.company} | {exp.period}
                  </p>
                  <p className="text-gray-700 dark:text-gray-300 mt-2">
                    {exp.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <style jsx global>{`
        @keyframes slideIn {
          from { transform: translateX(-100%); }
          to { transform: translateX(0); }
        }

        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }

        .animate-slideIn {
          animation: slideIn 1s ease-out forwards;
        }

        .animate-fadeIn {
          animation: fadeIn 0.6s ease-out forwards;
        }
      `}</style>
    </div>
  );
}

export default MainComponent;