"use client";
import React from "react";
import HomeButton from "../../components/home-button";

function MainComponent() {
  const [isVisible, setIsVisible] = useState({});
  const educationTimeline = [
    {
      id: 1,
      institution: "Jabalpur Engineering College",
      degree: "Bachelor of Technology - BTech, Mechatronics",
      period: "Sep 2023 - Sept 2027",
      icon: "fa-university",
      achievements:
        "Currently pursuing with focus on robotics and automation systems",
      current: true,
    },
    {
      id: 2,
      institution:
        "Pandit Lajja Shankar Jha Model Higher Secondary School of Excellence",
      degree: "Higher Secondary Education",
      period: "Mar 2020 - Mar 2023",
      icon: "fa-school",
      achievements:
        "Graduated with distinction in Physics, Chemistry, and Mathematics",
    },
    {
      id: 3,
      institution: "Aditya Convert School Senior Secondary School",
      degree: "Secondary Education",
      period: "Mar 2017 - Mar 2020",
      icon: "fa-school",
      achievements:
        "Active participation in science exhibitions and academic competitions",
    },
    {
      id: 4,
      institution: "Somja Nursery And Primary School",
      degree: "Primary Education",
      period: "2007 - 2017",
      icon: "fa-school",
    },
  ];
  const [selectedLanguage, setSelectedLanguage] = useState("en");
  const [isLoading, setIsLoading] = useState(false);
  const [translatedData, setTranslatedData] = useState(null);
  const translateContent = async (language) => {
    if (language === "en") {
      setTranslatedData(null);
      return;
    }

    setIsLoading(true);
    try {
      const textsToTranslate = educationTimeline.flatMap((item) =>
        [item.institution, item.degree, item.achievements].filter(Boolean)
      );

      textsToTranslate.push("Educational Journey");

      const response = await fetch(
        "/integrations/google-translate/language/translate/v2",
        {
          method: "POST",
          body: new URLSearchParams({
            q: textsToTranslate.join("\n"),
            target: language,
            source: "en",
          }),
        }
      );

      if (!response.ok) {
        throw new Error("Translation failed");
      }

      const data = await response.json();
      const translations = data.data.translations[0].translatedText.split("\n");

      let translationIndex = 0;
      const translatedTimeline = educationTimeline.map((item) => ({
        ...item,
        institution: translations[translationIndex++],
        degree: translations[translationIndex++],
        achievements: item.achievements
          ? translations[translationIndex++]
          : null,
      }));

      setTranslatedData({
        timeline: translatedTimeline,
        title: translations[translations.length - 1],
      });
    } catch (error) {
      console.error("Translation error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    translateContent(selectedLanguage);
  }, [selectedLanguage]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setIsVisible((prev) => ({
              ...prev,
              [entry.target.id]: true,
            }));
          }
        });
      },
      { threshold: 0.7 }
    );

    document.querySelectorAll(".timeline-item").forEach((item) => {
      observer.observe(item);
    });

    return () => observer.disconnect();
  }, []);

  const displayData = translatedData || {
    timeline: educationTimeline,
    title: "Educational Journey",
  };

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 py-20 px-4">
      <nav className="fixed top-0 left-0 right-0 bg-white dark:bg-gray-900 shadow-md z-50 px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <HomeButton className="relative top-0 left-0" />
          <div className="flex items-center space-x-4">
            <select
              value={selectedLanguage}
              onChange={(e) => setSelectedLanguage(e.target.value)}
              className="px-4 py-2 rounded-lg bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white border border-gray-300 dark:border-gray-700"
            >
              <option value="en">English</option>
              <option value="es">Español</option>
              <option value="fr">Français</option>
              <option value="de">Deutsch</option>
              <option value="hi">हिंदी</option>
              <option value="ja">日本語</option>
            </select>
            <a
              href="https://www.create.xyz/app/57e7a7aa-3e46-4391-8035-59f7f7422bf4"
              className="px-4 py-2 rounded-lg bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white border border-gray-300 dark:border-gray-700 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
            >
              About
            </a>
            <a
              href="https://www.create.xyz/app/73551bb1-322f-4568-a847-6e27b4b95b04"
              className="px-4 py-2 rounded-lg bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white border border-gray-300 dark:border-gray-700 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
            >
              Skills
            </a>
            <a
              href="https://www.create.xyz/app/c7f88f44-14db-4c46-849c-e19065b4fa2e"
              className="px-4 py-2 rounded-lg bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white border border-gray-300 dark:border-gray-700 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
            >
              Projects
            </a>
            <a
              href="https://www.create.xyz/app/c02b4fd5-77b4-4154-94bc-feec77a89db1"
              className="px-4 py-2 rounded-lg bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white border border-gray-300 dark:border-gray-700 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
            >
              Certifications
            </a>
            <a
              href="https://www.create.xyz/app/da55e7f9-b3a5-48d0-84bb-3b4688233a0f"
              className="px-4 py-2 rounded-lg bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white border border-gray-300 dark:border-gray-700 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
            >
              Contact
            </a>
            <a
              href="https://www.create.xyz/app/1b51b5e1-1295-4f1a-b86c-62b0968b012d"
              className="px-4 py-2 rounded-lg bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white border border-gray-300 dark:border-gray-700 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
            >
              Education
            </a>
          </div>
        </div>
      </nav>
      <div className="max-w-4xl mx-auto">
        <div className="relative mt-8">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white text-center mb-12">
            {isLoading ? (
              <span className="inline-block animate-pulse">Loading...</span>
            ) : (
              displayData.title
            )}
          </h1>
          <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-gray-200 dark:bg-gray-700"></div>

          {displayData.timeline.map((item) => (
            <div
              key={item.id}
              id={`timeline-${item.id}`}
              className={`timeline-item relative mb-12 ${
                isVisible[`timeline-${item.id}`] ? "opacity-100" : "opacity-0"
              } transition-opacity duration-500`}
            >
              <div
                className={`flex items-center ${
                  item.id % 2 === 0 ? "flex-row-reverse" : ""
                }`}
              >
                <div className="w-1/2 px-6">
                  <div
                    className={`bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg ${
                      item.current
                        ? "border-2 border-gray-900 dark:border-gray-300"
                        : ""
                    }`}
                  >
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                      {isLoading ? (
                        <span className="inline-block animate-pulse">
                          Loading...
                        </span>
                      ) : (
                        item.institution
                      )}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400 mb-2">
                      {isLoading ? (
                        <span className="inline-block animate-pulse">
                          Loading...
                        </span>
                      ) : (
                        item.degree
                      )}
                    </p>
                    <p className="text-gray-500 dark:text-gray-500 text-sm mb-3">
                      {item.period}
                    </p>
                    {item.achievements && (
                      <p className="text-gray-700 dark:text-gray-300">
                        {isLoading ? (
                          <span className="inline-block animate-pulse">
                            Loading...
                          </span>
                        ) : (
                          item.achievements
                        )}
                      </p>
                    )}
                  </div>
                </div>

                <div className="absolute left-1/2 transform -translate-x-1/2 flex items-center justify-center">
                  <div className="w-12 h-12 bg-gray-900 dark:bg-gray-300 rounded-full flex items-center justify-center">
                    <i
                      className={`fas ${item.icon} text-white dark:text-gray-900`}
                    ></i>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <style jsx global>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }

        .timeline-item {
          animation: fadeIn 0.6s ease-out forwards;
        }
      `}</style>
    </div>
  );
}

export default MainComponent;