"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ className = '' }) {
  return (
    <a 
      href="https://www.create.xyz/app/bda19650-59e0-4d5c-9d80-da429604c092"
      className={`fixed top-5 left-5 px-6 py-3 bg-[rgba(17,24,39,0.9)] text-white rounded-full flex items-center gap-2 transition-all duration-300 ease-in-out hover:-translate-y-0.5 hover:bg-[rgba(17,24,39,1)] hover:shadow-lg shadow-md z-50 no-underline ${className}`}
    >
      <i className="fas fa-home"></i>
      <span className="text-base md:text-sm">Home</span>
    </a>
  );
}

function StoryComponent() {
  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <h2 className="text-2xl font-bold mb-8">Home Button Component</h2>
      
      <div className="space-y-8">
        <div>
          <h3 className="text-lg font-semibold mb-4">Default State</h3>
          <MainComponent />
        </div>

        <div>
          <h3 className="text-lg font-semibold mb-4">With Custom Class</h3>
          <MainComponent 
            className="!bg-blue-600"
          />
        </div>

        <div className="bg-gray-900 p-8 rounded-lg">
          <h3 className="text-lg font-semibold mb-4 text-white">On Dark Background</h3>
          <MainComponent />
        </div>
      </div>
    </div>
  );
});
}